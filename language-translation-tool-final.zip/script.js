async function translateText() {
  const text = document.getElementById("inputText").value;
  const sourceLang = document.getElementById("sourceLang").value;
  const targetLang = document.getElementById("targetLang").value;
  const output = document.getElementById("translatedText");

  if (!text) {
    output.innerText = "Please enter some text.";
    return;
  }

  try {
    const res = await fetch("https://translate.astian.org/translate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        q: text,
        source: sourceLang,
        target: targetLang,
        format: "text"
      })
    });

    const data = await res.json();
    output.innerText = data.translatedText || "Translation failed.";
  } catch (error) {
    output.innerText = "Error: Unable to translate.";
    console.error(error);
  }
}

function copyText() {
  const text = document.getElementById("translatedText").innerText;
  navigator.clipboard.writeText(text);
  alert("Copied to clipboard!");
}

function speakText() {
  const text = document.getElementById("translatedText").innerText;
  const speech = new SpeechSynthesisUtterance(text);
  speech.lang = document.getElementById("targetLang").value;
  window.speechSynthesis.speak(speech);
}